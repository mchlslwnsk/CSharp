﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Program2
{
    class FileIO
    {
        public void WriteToFile(string fileName, string data)
        {
            StreamWriter writer = new StreamWriter(fileName, false, Encoding.UTF8);
            writer.Write(data);
            writer.Close();

        }
    }
}
