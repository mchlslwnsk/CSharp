﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Program2
{
    class Program
    {
        static void Main(string[] args)
        {
            HTTP http = new HTTP();

            string data = http.GetHtml("http://wypako.uni.lodz.pl/ekon/dyda/b.htm");

            FileIO io = new FileIO();
            

            int start = data.IndexOf("RI16 - MGR MICHAL BLASZCZYK");
            int length = data.IndexOf("SU03 - DR MARIA BLASZCZYK") - start;
            data = data.Substring(start, length).Replace("<pre>","").Replace("</pre>", Environment.NewLine);

            int st = -1;
            do{
                st = data.IndexOf("<a href=#");
                if(st != -1)
                {
                    int end = data.IndexOf("</a><hr>") + 8;
                    if (end > st)
                    {
                        data = data.Remove(st, end - st);
                    }
                   
                }
            }while (st != -1);

            Console.Write(data);

            string data2 = http.SendRequest("http://kie.uni.lodz.pl/manager/staff/login.php", "login=abc&pass=xyz");
            io.WriteToFile(@"C:\Users\blaszczyk\Desktop\request.htm", data2);

            Console.ReadKey();
        }
    }
}
