﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;

namespace Program2
{
    class HTTP
    {
        public string GetHtml(string url)
        {
            WebRequest request = WebRequest.Create(url);
            WebResponse response = request.GetResponse();

            StreamReader reader = new StreamReader(response.GetResponseStream());

            string html = reader.ReadToEnd();
            reader.Close();

            return html;
        }

        public string SendRequest(string url, string parameters)
        {
            WebRequest request = WebRequest.Create(url);
            
            byte[] b = Encoding.UTF8.GetBytes(parameters);
            request.Method = "POST";
            request.ContentLength = b.Length;

            Stream writer = request.GetRequestStream();
            writer.Write(b, 0, b.Length);
            writer.Close();

            WebResponse response = request.GetResponse();

            StreamReader reader = new StreamReader(response.GetResponseStream());

            string html = reader.ReadToEnd();
            reader.Close();

            return html;
        }
    }
}
