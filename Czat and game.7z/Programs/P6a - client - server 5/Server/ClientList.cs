﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace Server
{
    class ClientList
    {
        static List<ClientData> list = new List<ClientData>();

        public static List<ClientData> getList()
        {
            return list;
        }
    }
}
