﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace Server
{
    class Server
    {
        public void StartListening()
        {
            try
            {
                TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 999);
                listener.Start();

                ThreadStart ts1 = new ThreadStart(StartServerCom);
                Thread t1 = new Thread(ts1);
                t1.Start();

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();

                    if (client.Connected)
                    {
                        Console.WriteLine("Klient {0} połączony", client.Client.RemoteEndPoint.ToString());

                        ClientData clientData = new ClientData();
                        clientData.Client = client;
                        clientData.IpAddress = client.Client.RemoteEndPoint.ToString();
                        clientData.LastMessage = DateTime.Now;
                        clientData.MessageCount = 0;

                        SendMessage("Podaj swoje imię", client);
                        string name = ReciveMessege(client);

                        clientData.Name = name;

                        ClientList.getList().Add(clientData);

                        Console.WriteLine("Liczba połączonych klientów: {0}", ClientList.getList().Count);

                        ParameterizedThreadStart ts = new ParameterizedThreadStart(StartReciving);
                        Thread t = new Thread(ts);
                        t.Start(clientData);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void StartReciving(object c)
        {
            try
            {
                ClientData clientData = (ClientData)c;
                BinaryReader reader = new BinaryReader(clientData.Client.GetStream());
                while (true)
                {
                    try
                    {
                        string data = reader.ReadString();

                        if (data.StartsWith("comm>"))
                        {
                            ExecuteCommand(data, clientData);
                        }
                        else
                        {
                            Console.WriteLine(data);
                            SendMessage(string.Format("Użytkownik {0} napisał: {1}", clientData.Name, data));
                            clientData.LastMessage = DateTime.Now;
                            clientData.MessageCount++;
                        }
                    }
                    catch { Console.WriteLine("Klient {0} został rozłączony", clientData.IpAddress); reader.Close(); }

                }
            }
            catch { }
        }

        private void ExecuteCommand(string data, ClientData clientData)
        {
            switch (data)
            {
                case "comm>list": SendClientList(clientData.Client); break;
                case "comm>private": SendPrivateMessage(clientData); break;
                default: SendMessage("Nieznana komenda", clientData.Client); break;
            }
        }

        private string ReciveMessege(TcpClient client)
        {
            BinaryReader reader = new BinaryReader(client.GetStream());
            try
            {
                string data = reader.ReadString();
                return data;
            }
            catch { Console.WriteLine("Klient {0} został rozłączony", client.Client.RemoteEndPoint.ToString()); reader.Close(); return "Niepowodzenie!"; }
        }

        private void StartServerCom()
        {
            while (true)
            {
                Console.WriteLine("Wybierz opcję:");
                Console.WriteLine("1. Wyświtl listę klientów");               
                Console.WriteLine("2. Wyśli komunikat do klientów");
                Console.WriteLine("3. Rozłącz klienta");

                ConsoleKey key = Console.ReadKey().Key;

                switch (key)
                {
                    case ConsoleKey.D1: ShowClientList(); break;
                    case ConsoleKey.D2: SendMessage(); break;
                    case ConsoleKey.D3: DisconnectClient(); break;
                    
                }

            }
        }

        private void ShowClientList()
        {
            int i = 0;
            Console.WriteLine("---------------------");
            foreach (ClientData c in ClientList.getList())
            {
                Console.WriteLine("{0}. {1} - {2} ({3}) (Ostatnia wiadomiość:{4})", i, c.Name, c.IpAddress, c.Active , c.LastMessage.ToShortTimeString());
                i++;
            }
            Console.WriteLine("-------------------------");
        }

        private void SendClientList(TcpClient client)
        {
            int i = 0;
            BinaryWriter writer = new BinaryWriter(client.GetStream());
            foreach (ClientData c in ClientList.getList())
            {
                writer.Write(string.Format("{0}. {1} - {2} ({3}) (Ostatnia wiadomiość:{4})", i, c.Name, c.IpAddress, c.Active, c.LastMessage.ToShortTimeString()));
                i++;
            }
        }

        private void SendMessage()
        {
            try
            {
                Console.WriteLine("Wpisz komunikat do wysłania:");
                string data = Console.ReadLine();

                foreach (ClientData c in ClientList.getList())
                {
                    BinaryWriter writer = new BinaryWriter(c.Client.GetStream());
                    writer.Write(data);
                }
            }
            catch { }
        
        }

        private void SendMessage(string message)
        {
            try
            {
                foreach (ClientData c in ClientList.getList())
                {
                    BinaryWriter writer = new BinaryWriter(c.Client.GetStream());
                    writer.Write(message);
                }
            }
            catch { }
        }


        private void SendMessage(string message, TcpClient client)
        {
            try
            {
                    BinaryWriter writer = new BinaryWriter(client.GetStream());
                    writer.Write(message);
            }
            catch { }
        }

        private void SendPrivateMessage(ClientData clientData)
        {
            SendMessage("Wybierz do kogo skierowana ma być wiadomość:", clientData.Client);
            SendClientList(clientData.Client);

            int i = -1;
            bool ok = int.TryParse(ReciveMessege(clientData.Client), out i);

            if (ok && i >= 0 && i < ClientList.getList().Count)
            {
                SendMessage("Podaj treść wiadomości:", clientData.Client);
                string data = ReciveMessege(clientData.Client);

                TcpClient clientToSend = ClientList.getList()[i].Client;
                SendMessage(string.Format("Prywatna wiadomość od {0}:{1}",clientData.Name, data), clientToSend);
            }
            else
            {
                Console.WriteLine("Błędny numer klienta");
            }

        }

        private void DisconnectClient()
        {
            Console.WriteLine("Wybierz klienta do rozłączenia");
            ShowClientList();

            int i = -1;
            bool ok = int.TryParse(Console.ReadLine(), out i);

            if (ok && i >= 0 && i < ClientList.getList().Count)
            {
                ClientList.getList()[i].Client.Close();
                ClientList.getList().RemoveAt(i);
            }
            else
            {
                Console.WriteLine("Błędny numer klienta");
            }
           
        
        }
    }
}
