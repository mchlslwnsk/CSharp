﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace Server
{
    class Server
    {
        public void StartListening()
        {
            try
            {
                TcpListener listener = new TcpListener(IPAddress.Parse("10.0.215.17"), 999);
                listener.Start();

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();

                    if (client.Connected)
                    {
                        Console.WriteLine("Klient {0} połączony", client.Client.RemoteEndPoint.ToString());

                        ParameterizedThreadStart ts = new ParameterizedThreadStart(StartReciving);
                        Thread t = new Thread(ts);
                        t.Start(client);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void StartReciving(object c)
        {
            try
            {
                TcpClient client = (TcpClient)c;
                BinaryReader reader = new BinaryReader(client.GetStream());
                while (true)
                {
                    try
                    {
                        Console.WriteLine(reader.ReadString());
                    }
                    catch { Console.WriteLine("Klient {0} został rozłączony", client.Client.RemoteEndPoint.ToString()); reader.Close(); }

                }
            }
            catch { }
        }
    }
}
