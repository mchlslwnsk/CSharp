﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace Server
{
    class Server
    {
        public void StartListening()
        {
            TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 13);
            listener.Start();

            Console.WriteLine("Nasłuchiwanie rozpoczęte");
            TcpClient client = listener.AcceptTcpClient();

            if (client.Connected)
            {
                Console.WriteLine("Połączono klienta");

                BinaryWriter writer = new BinaryWriter(client.GetStream());
                writer.Write("Witaj na serwerze - Program_3");
                writer.Write("Podaj imię");

                BinaryReader reader = new BinaryReader(client.GetStream());

                while (true)
                {
                    Console.WriteLine(reader.ReadString());
                }

                writer.Close();
                reader.Close();
            }

        }
    }
}
