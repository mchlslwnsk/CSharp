﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Client c = new Client();
            c.Connect("10.0.215.17", 13000);

            Console.ReadKey();
        }
    }
}
