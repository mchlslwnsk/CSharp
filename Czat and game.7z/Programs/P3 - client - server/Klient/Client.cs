﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace Client
{
    class Client
    {
        public void Connect(string ip, int port)
        {
            TcpClient client = new TcpClient();

            Console.WriteLine("Próba połączenie z serwerem");
            client.Connect(IPAddress.Parse(ip), port);

            if (client.Connected)
            {
                Console.WriteLine("Połączono z serwerem");

                BinaryReader reader = new BinaryReader(client.GetStream());
                Console.WriteLine(reader.ReadString());
                Console.WriteLine(reader.ReadString());

                BinaryWriter writer = new BinaryWriter(client.GetStream());

                while (true)
                {
                    writer.Write(Console.ReadLine());
                }

                reader.Close();
                writer.Close();

            }

        }
    }
}
