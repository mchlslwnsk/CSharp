﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Server2
{
    class Program
    {
        static void Main(string[] args)
        {
            Server s = new Server();
            s.StartListening();
        }
    }
}
