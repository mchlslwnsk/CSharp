﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace Server2
{
    class Server
    {
        public void StartListening()
        {
            TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 13);
            listener.Start();

            Console.WriteLine("Nasłuchiwanie rozpoczęte");
            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();

                if (client.Connected)
                {
                    Console.WriteLine("Połączono klienta:{0}", client.Client.RemoteEndPoint.ToString());
                }
            }
        }
    }
}
