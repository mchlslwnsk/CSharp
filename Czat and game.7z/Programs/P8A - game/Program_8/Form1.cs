﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Program_8
{
    public partial class Form1 : Form
    {
        Player localPlayer;
        Player remotePlayer;
        UdpClient client = new UdpClient(888);

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            localPlayer = new Player(120, 120, "Gracz 1", Color.Red);
            remotePlayer = new Player(100, 100, "Gracz zdalny", Color.Blue);

            client.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"),999));
            backgroundWorker1.RunWorkerAsync();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics grx = e.Graphics;

            Rectangle rect = new Rectangle(localPlayer.PosX, localPlayer.PosY,10,10);
            Pen pen = new Pen(localPlayer.Color,2);
            grx.DrawRectangle(pen, rect);
            grx.DrawString(localPlayer.Name, new System.Drawing.Font("Arial", 10, FontStyle.Regular), Brushes.Black, new PointF(localPlayer.PosX - 15, localPlayer.PosY - 20));

            Rectangle rect2 = new Rectangle(remotePlayer.PosX, remotePlayer.PosY, 10, 10);
            Pen pen2 = new Pen(remotePlayer.Color, 2);
            grx.DrawRectangle(pen2, rect2);
            grx.DrawString(remotePlayer.Name, new System.Drawing.Font("Arial", 10, FontStyle.Regular), Brushes.Black, new PointF(remotePlayer.PosX - 15, remotePlayer.PosY - 20));

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (client.Client.Connected)
            { 
                byte[] key = Encoding.Default.GetBytes(e.KeyCode.ToString());
                client.Send(key, key.Length);
            }

            if (e.KeyCode == Keys.Up)
            {
                localPlayer.PosY -= 10;
            }
            else if (e.KeyCode == Keys.Down)
            {
                localPlayer.PosY += 10;
            }
            else if (e.KeyCode == Keys.Left)
            {
                localPlayer.PosX -= 10;
            }
            else if (e.KeyCode == Keys.Right)
            {
                localPlayer.PosX += 10;
            }

            this.Invalidate();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            { 
                IPEndPoint ipEP = new IPEndPoint(IPAddress.Any,0);
                byte[] key = client.Receive(ref ipEP);
                
                KeysConverter kk = new KeysConverter();
                Keys keyCode = (Keys)kk.ConvertFromString(Encoding.Default.GetString(key));

                if (keyCode == Keys.Up)
                {
                    remotePlayer.PosY -= 10;
                }
                else if (keyCode == Keys.Down)
                {
                    remotePlayer.PosY += 10;
                }
                else if (keyCode == Keys.Left)
                {
                    remotePlayer.PosX -= 10;
                }
                else if (keyCode == Keys.Right)
                {
                    remotePlayer.PosX += 10;
                }

                this.Invalidate();
            }
        }
    }
}
