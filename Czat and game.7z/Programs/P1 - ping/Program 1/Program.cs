﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Program_1
{
    class Program
    {
        static void Main(string[] args)
        {

            while (true)
            {

                Menu.CreateMainMenu();

                ConsoleKeyInfo ci = Console.ReadKey();
                ConsoleKey c = ci.Key;

                Menu.ExecuteMainMenu(c);
            }
        }
    }
}
