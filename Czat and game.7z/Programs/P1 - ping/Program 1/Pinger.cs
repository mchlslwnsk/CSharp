﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.NetworkInformation;

namespace Program_1
{
    class Pinger
    {
        public void PingOwnNet() {

            string localIP = null;

            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());

            foreach (IPAddress address in host.AddressList)
            {
                if (address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    localIP = address.ToString();
                    break;
                }
            }

            if (localIP == null)
            {
                Console.WriteLine("Nie można pobrać lokalnego adresu IP"); return;
            }

            Ping ping = new Ping();
            string[] net = localIP.Split('.');

            for (int i = 1; i < 25; i++)
            {
                string address = String.Format("{0}.{1}.{2}.{3}", net[0], net[1], net[2], i);
                PingReply pr = ping.Send(address);

                Console.WriteLine("{0} - {1}", address, pr.Status);
            }

        
        }
        public void PingNet() { }
        public void PingHost() { }
    }
}
