﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Program_1
{
    public class Menu
    {
        public static void CreateMainMenu()
        {
            Console.WriteLine("1. Pinguj własną podsieć");
            Console.WriteLine("2. Pinguj wybraną podsieć");
            Console.WriteLine("3. Pinguj adres");
            Console.WriteLine("4. Koniec");
        }

        public static void ExecuteMainMenu(ConsoleKey c)
        {
            Pinger p = new Pinger();

            switch (c)
            {
                case ConsoleKey.D1: p.PingOwnNet() ; break;
                case ConsoleKey.NumPad1: p.PingOwnNet(); break;
                case ConsoleKey.D2: p.PingNet(); break;
                case ConsoleKey.NumPad2: p.PingNet(); ; break;
                case ConsoleKey.D3: p.PingHost(); break;
                case ConsoleKey.NumPad3: p.PingHost(); ; break;
                case ConsoleKey.D4: return;
                case ConsoleKey.NumPad4: return;
            }
        }
    }
}
