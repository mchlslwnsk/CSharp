﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;


namespace Program_8_Gra
{
    public partial class Form1 : Form
    {

        Player Player1;
        Player Player2;
        UdpClient client = new UdpClient(888);

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Player1 = new Player(100, 100, "Gracz 1", Color.Orange);
            Player2 = new Player(120, 120, "Gracz 2", Color.Green);
            client.Connect(new IPEndPoint(IPAddress.Parse("10.0.215.5"), 888));
            backgroundWorker1.RunWorkerAsync();

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics grx = e.Graphics;

            Rectangle rect = new Rectangle(Player1.PosX,Player1.PosY,10,10);
            Pen pen = new Pen(Player1.Color,10);
            grx.DrawRectangle(pen, rect);
            grx.DrawString(Player1.Name,new System.Drawing.Font("Times New Roman",11,FontStyle.Regular), Brushes.Black, new PointF(Player1.PosX -15, Player1.PosY -20));

            
            Rectangle rect2 = new Rectangle(Player2.PosX, Player2.PosY, 10, 10);
            Pen pen2 = new Pen(Player2.Color, 10);
            grx.DrawRectangle(pen2, rect2);
            grx.DrawString(Player2.Name, new System.Drawing.Font("Times New Roman", 11, FontStyle.Regular), Brushes.Black, new PointF(Player2.PosX - 15, Player2.PosY - 20));
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            if (client.Client.Connected)
            {
                byte[] key = Encoding.Default.GetBytes(e.KeyCode.ToString());
                client.Send(key, key.Length);
            }

            if (e.KeyCode == Keys.Up)
            {
                Player1.PosY -= 10;

            }
            else if (e.KeyCode==Keys.Down)
            {
                Player1.PosY += 10;
            }
            if (e.KeyCode == Keys.Left)
            {
                Player1.PosX -= 10;

            }
            else if (e.KeyCode == Keys.Right)
            {
                Player1.PosX += 10;
            }
            if (Player1.PosX == Player2.PosX && Player1.PosY==Player2.PosY)
            {
                MessageBox.Show("HIT");

            }

            this.Invalidate();
        }

   

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                IPEndPoint ipEP = new IPEndPoint(IPAddress.Any, 0);
                byte[] key = client.Receive(ref ipEP);
                KeysConverter kk = new KeysConverter();
                Keys keyCode = (Keys)kk.ConvertFromString(Encoding.Default.GetString(key));

                if (keyCode == Keys.Up)
                {
                    Player2.PosY -= 10;
                }
                else if (keyCode == Keys.Down)
                {
                    Player2.PosY += 10;
                }
                else if (keyCode == Keys.Left)
                {
                    Player2.PosX -= 10;
                }
                else if (keyCode == Keys.Right)
                {
                    Player2.PosX += 10;
                }
                if (Player1.PosX == Player2.PosX && Player1.PosY == Player2.PosY)
                {
                    MessageBox.Show("HIT");

                }

                this.Invalidate();
            }
        }
    }
}
