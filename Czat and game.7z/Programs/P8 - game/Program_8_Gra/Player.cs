﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Program_8_Gra
{
    class Player
    {
        public int PosX{get;set;}
        public int PosY{get;set;}
        public string Name { get; set; }
        public System.Drawing.Color Color { get; set; }

        public Player(int posX, int posY, string name, System.Drawing.Color color)
        {
            PosX = posX;
            PosY = posY;
            Name = name;
            Color = color;

        }
    }
}
