﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace Server
{
    class ClientData
    {
        public TcpClient Client { get; set; }
        public string Name { get; set; }
        public string IP { get; set; }
        public int MessageCount { get; set; }
        public DateTime LastMessage { get; set; }
        public bool Active
        {
            get {
                if (LastMessage.AddMinutes(1) < DateTime.Now)
                {
                    return true;
                } return false;
            }
        }
    }
}
