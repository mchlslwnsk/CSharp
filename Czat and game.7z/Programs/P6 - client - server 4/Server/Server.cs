﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace Server
{
    class Server
    {
        public void StartListening()
        {
            try
            {
                TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 999);
                listener.Start();

                ThreadStart ts1 = new ThreadStart(StartServerCom);
                Thread t1 = new Thread(ts1);
                t1.Start();

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();

                    if (client.Connected)
                    {
                        Console.WriteLine("Klient {0} połączony", client.Client.RemoteEndPoint.ToString());
                        SendMessage("Podaj Imię:", client);
                        string name = ReciveMessage(client);

                        ClientData clientData = new ClientData();
                        clientData.Name = name;
                        clientData.IP = client.Client.RemoteEndPoint.ToString();
                        clientData.LastMessage = DateTime.Now;
                        clientData.MessageCount = 0;
                        clientData.Client = client;


                        ClientList.getList().Add(clientData);

                        Console.WriteLine("Liczba połączonych klientów: {0}", ClientList.getList().Count);

                        ParameterizedThreadStart ts = new ParameterizedThreadStart(StartReciving);
                        Thread t = new Thread(ts);
                        t.Start(clientData);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void StartReciving(object c)
        {
            try
            {
                ClientData client = (ClientData)c;
                BinaryReader reader = new BinaryReader(client.Client.GetStream());
                while (true)
                {
                    try
                    {
                        string data = reader.ReadString();

                        client.LastMessage = DateTime.Now;
                        client.MessageCount++;

                        if (data.StartsWith("com>>"))
                        {
                            SendCommand(data, client);
                        }
                        else
                        {
                            Console.WriteLine(data);
                            SendMessage(String.Format("{0} napisał: {1}", client.Name, data));
                        }


                    }
                    catch { Console.WriteLine("Klient {0} został rozłączony", client.IP); reader.Close(); }

                }
            }
            catch { }
        }

        private void SendCommand(string command, ClientData clientData)
        {
            switch (command)
            {
                case "com>>lista": SendClientList(clientData); break;
                case "com>>newName": ChangeClientName(clientData); break;
                case "com>>private": SendPrivateMessage(clientData); break;
                default: SendMessage("Nieznana komenda", clientData.Client); break;
            }
        }

        private string ReciveMessage(TcpClient c)
        {
            try
            {
                BinaryReader reader = new BinaryReader(c.GetStream());
                string data = reader.ReadString();
                return data;
            }
            catch { return "Nieudane przesłanie danych"; }
        }

        private void StartServerCom()
        {
            while (true)
            {
                Console.WriteLine("Wybierz opcję:");
                Console.WriteLine("1. Wyświtl listę klientów");               
                Console.WriteLine("2. Wyśli komunikat do klientów");
                Console.WriteLine("3. Rozłącz klienta");

                ConsoleKey key = Console.ReadKey().Key;

                switch (key)
                {
                    case ConsoleKey.D1: ShowClientList(); break;
                    case ConsoleKey.D2: SendMessage(); break;
                    case ConsoleKey.D3: DisconnectClient(); break;
                    
                }

            }
        }

        private void ChangeClientName(ClientData clientData)
        {
            SendMessage("Podaj nowe imię",clientData.Client);
            string data = ReciveMessage(clientData.Client);
            clientData.Name = data;
        }

        private void ShowClientList()
        {
            int i = 0;
            Console.WriteLine("---------------------");
            foreach (ClientData c in ClientList.getList())
            {
                Console.WriteLine("{0}. {1} - {2} ({3}) ({4} wiadomości), ostatnia o :{5}",i, c.Name, c.IP, c.Active, c.MessageCount, c.LastMessage.ToShortTimeString());
                i++;
            }
            Console.WriteLine("-------------------------");
        }

        private void SendClientList(ClientData clientData)
        {
            int i = 0;

            BinaryWriter writer = new BinaryWriter(clientData.Client.GetStream());

            foreach (ClientData c in ClientList.getList())
            {
                writer.Write(String.Format("{0}. {1} - {2} ({3}) ({4} wiadomości), ostatnia o :{5}", i, c.Name, c.IP, c.Active, c.MessageCount, c.LastMessage.ToShortTimeString()));
                i++;
            }  
        }

        private void SendMessage()
        {
            try
            {
                Console.WriteLine("Wpisz komunikat do wysłania:");
                string data = Console.ReadLine();

                foreach (ClientData c in ClientList.getList())
                {
                    BinaryWriter writer = new BinaryWriter(c.Client.GetStream());
                    writer.Write(data);
                }
            }
            catch { }
        
        }

        private void SendMessage(string message)
        {
            try
            {
                foreach (ClientData c in ClientList.getList())
                {
                    BinaryWriter writer = new BinaryWriter(c.Client.GetStream());
                    writer.Write(message);
                }
            }
            catch { }

        }

        private void SendMessage(string message, TcpClient client)
        {
            try
            {
                    BinaryWriter writer = new BinaryWriter(client.GetStream());
                    writer.Write(message);
            }
            catch { }

        }

        private void DisconnectClient()
        {
            Console.WriteLine("Wybierz klienta do rozłączenia");
            ShowClientList();

            int i = -1;
            bool ok = int.TryParse(Console.ReadLine(), out i);

            if (ok && i >= 0 && i < ClientList.getList().Count)
            {
                ClientList.getList()[i].Client.Close();
                ClientList.getList().RemoveAt(i);
            }
            else
            {
                Console.WriteLine("Błędny numer klienta");
            }
           
        
        }

        private void SendPrivateMessage(ClientData clientData)
        {
            SendMessage("Wybierz użytkownika:", clientData.Client);
            SendClientList(clientData);

            string id = ReciveMessage(clientData.Client);

            int i = -1;
            bool ok = int.TryParse(id, out i);

            if (ok && i >= 0 && i < ClientList.getList().Count)
            {
                TcpClient toSend = ClientList.getList()[i].Client;
                string data = ReciveMessage(clientData.Client);
                SendMessage(string.Format("Prywatna wiadomość od użytkownika {0}: {1}", clientData.Name, data), toSend);

            }
            else
            {
                SendMessage("Błędny wybór", clientData.Client);
            }


        }
    }
}
