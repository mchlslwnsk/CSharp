﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace Program_4
{
    class Client
    {
        public void Connect(string ip, int port)
        {
            try
            {
                TcpClient client = new TcpClient();
                client.Connect(new IPEndPoint(IPAddress.Parse(ip), port));

                if (client.Connected)
                {
                    Console.WriteLine("Połączono do serwera");
                    
                    ParameterizedThreadStart ts = new ParameterizedThreadStart(StartReciving);
                    Thread t = new Thread(ts);
                    t.Start(client);

                    StartSending(client);
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

        }

        private void StartSending(TcpClient client)
        {
            try
            {
                BinaryWriter writer = new BinaryWriter(client.GetStream());
                while (true)
                {
                    try
                    {
                        string data = Console.ReadLine();
                        writer.Write(data);
                    }
                    catch
                    {
                        Console.WriteLine("Utracono połączenie z serwerem"); writer.Close();
                    }
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
        }

        private void StartReciving(object c)
        {
            try{
                TcpClient client = (TcpClient)c;
                BinaryReader reader = new BinaryReader(client.GetStream());
                while (true)
                {
                    try
                    {
                        Console.WriteLine(reader.ReadString());
                    }
                    catch { Console.WriteLine("Klient {0} został rozłączony", client.Client.RemoteEndPoint.ToString()); reader.Close(); }
                }
            }
            catch { Console.ReadKey(); }
        }
    }
}
