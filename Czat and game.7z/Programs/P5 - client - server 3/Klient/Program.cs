﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Program_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Client c = new Client();
            c.Connect("127.0.0.1", 999);
        }
    }
}
