﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace Server
{
    class Server
    {
        public void StartListening()
        {
            try
            {
                TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 999);
                listener.Start();

                ThreadStart start = new ThreadStart(StartCom);
                Thread thread = new Thread(start);
                thread.Start();

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();

                    if (client.Connected)
                    {
                        Console.WriteLine("Klient {0} połączony", client.Client.RemoteEndPoint.ToString());
                        ClientList.getList().Add(client);

                        Console.WriteLine("Liczba podłączonych klientów: {0}", ClientList.getList().Count);

                        ParameterizedThreadStart ts = new ParameterizedThreadStart(StartReciving);
                        Thread t = new Thread(ts);
                        t.Start(client);

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }

        private void StartReciving(object c)
        {
            try
            {
                TcpClient client = (TcpClient)c;
                BinaryReader reader = new BinaryReader(client.GetStream());
                while (true)
                {
                    try
                    {
                        Console.WriteLine(reader.ReadString());
                    }
                    catch { Console.WriteLine("Klient {0} został rozłączony", client.Client.RemoteEndPoint.ToString()); reader.Close(); }

                }
            }
            catch { Console.ReadKey(); }
        }

        private void StartCom()
        {
            while (true)
            {
                Console.WriteLine("Wybierz polecenie:");
                Console.WriteLine("1. Wyświetl listę klientów");
                Console.WriteLine("2. Napisz wiadomość do klienta");
                Console.WriteLine("3. Rozłącz klienta");

                ConsoleKey key = Console.ReadKey().Key;
                Console.WriteLine();

                switch (key)
                {
                    case ConsoleKey.D1: ShowClientList(); break;
                    case ConsoleKey.D2: SendMessage();  break;
                    case ConsoleKey.D3: DeleteClient();  break;
                }
            }
        }

        private void ShowClientList()
        {
            int i = 0;
            foreach (TcpClient client in ClientList.getList())
            {
                Console.WriteLine("{0}. {1}", i, client.Client.RemoteEndPoint.ToString());
                i++;
            }
        }

        private void SendMessage()
        {
          string message =  Console.ReadLine();

          foreach (TcpClient client in ClientList.getList())
          {
              BinaryWriter writer = new BinaryWriter(client.GetStream());
              writer.Write(message);
          }
        }

        private void DeleteClient()
        {
            Console.WriteLine("Wybierz klienta do rozłączenia");
            ShowClientList();

            string clientID = Console.ReadLine();

            bool ok = false;
            int i;

            do
            {
                ok = int.TryParse(clientID, out i);
            }while(!ok || i > ClientList.getList().Count -1);

            ClientList.getList()[i].Close();
            ClientList.getList().RemoveAt(i);

        }
    }
}
