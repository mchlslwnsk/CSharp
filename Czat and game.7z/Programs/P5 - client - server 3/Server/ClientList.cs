﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace Server
{
    class ClientList
    {
        static List<TcpClient> list = new List<TcpClient>();

        public static List<TcpClient> getList()
        {
            return list;
        }

    }
}
