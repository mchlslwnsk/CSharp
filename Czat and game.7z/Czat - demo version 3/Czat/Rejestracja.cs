﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Czat
{
    public partial class Rejestracja : Form
    {
        public int id; // zmienna do nadawania numeru id
        public string fullpath; // zmienna sciezka do katalogu rejestracji
        public Rejestracja() //metoda inicjujaca rejestracje
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) // przycisk odpalajacy tworzenie konta
        {
            try
            { //obsluga pustych pól
                if (textBox3.Text.Length == 0 || textBox2.Text.Length == 0)
                {
                    MessageBox.Show("Puste pola wymagają wypełnienia", "Błąd");
                }
                    
                else
                {
                    //nadawanie numeru id i tworzenie katalogu z nadanym numerem, nazwa i haslem
                    Random r = new Random();
                    id = r.Next(1000, 9999);
                    MessageBox.Show("Stworzono Konto!Twój numer to: " + id, "Konto");

                    //fullpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\";
                    //var sw = new System.IO.StreamWriter(fullpath + id + "\\login.ID");
                    System.IO.Directory.CreateDirectory("C:\\ProgramUsers\\" + id);
                    var sw = new System.IO.StreamWriter("C:\\ProgramUsers\\" + id + "\\login.ID");
                    sw.Write(id + "\n" + textBox2.Text + "\n" + textBox3.Text);
                    sw.Close();



                }
            }
                // zapisywanie w katalogu odpowiednich danych w odpowiednich wierszach
            catch (System.IO.DirectoryNotFoundException ex)
            {
                //System.IO.Directory.CreateDirectory(fullpath + id);
               // var sw = new System.IO.StreamWriter(fullpath + id + "\\login.ID");
                System.IO.Directory.CreateDirectory("C:\\ProgramUsers\\" + id);
                var sw = new System.IO.StreamWriter("C:\\ProgramUsers\\" + id + "\\login.ID");

                sw.Write(id + "\n" + textBox2.Text + "\n" + textBox3.Text);
                sw.Close();
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e) //rezygnacja z rejestracji
        {
            this.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
