﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq; //---Dodatkowa bilbioteka nie pamiętam za co odpowiada---
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Net;



namespace Czat
{
    public partial class frm_klient : Form
    {
        //---Deklaracja streamu i gniazda---
        TcpClient clientSocket = new System.Net.Sockets.TcpClient(); // stworzenie nowego gniazda 
        NetworkStream serverStream = default(NetworkStream); // stworzenie strumienia sieciowego dla serwera
        string readData = null; // odczytanie danych logowania
        //string listaklientow = null; // lista klientow
        public string user, pass, login; // uzytkownik, haslo i login
        int buffSize = 0; //rozmiar bufora
        //int buffSize2 = 0; //rozmiar bufora na drugi strumien
        Thread ctThread; //stworzenie wątku
        //string fullpath; //sciezka katalogu
                
        public frm_klient() // forma okna klienta
        {
            InitializeComponent();
            label6.Text = DateTime.Now.ToShortDateString();
        }
        //dołączenie do czatu 
        private void btn_login_Click(object sender, EventArgs e) // obsluga przycisk do logowania do serwera
        {
            //warunek sprawdzający czy istnieje lista kontaktów prywatnych, jeśli nie to tworzy ją w katalogu klienta
            if (!File.Exists("C:\\ProgramUsers\\" + textBox1.Text + "\\friends.txt"))
            {
                using (StreamWriter sw = File.CreateText("C:\\ProgramUsers\\" + textBox1.Text + "\\friends.txt"))
                {
                }

            }
            //jeżeli istnieje to odczytuje ją i wyświetla w lst_prv
            else
            {
                using (StreamReader r = new StreamReader("C:\\ProgramUsers\\" + textBox1.Text + "\\friends.txt"))
                {
                    string line;
                    while ((line = r.ReadLine()) != null)
                    {
                        lst_prv.Items.Add(line);
                    }
                }
                readData = "Podlaczono do serwera...";  //wpis o podlaczeniu do serwera

                msg(); // wiadomosc
                clientSocket.Connect("127.0.0.1", 8888); // polaczenie z gniazdem klienta wg nawiasu
                serverStream = clientSocket.GetStream(); // pozyskanie przez serwer strumienia od klienta

                //byte[] inStreamLst = new byte[10025];
                //buffSize2 = clientSocket.ReceiveBufferSize;
                //serverStream.Read(inStreamLst, 0, buffSize2);
                //string listaklientow = System.Text.Encoding.ASCII.GetString(inStreamLst);
                //lst_kontakty.Text = listaklientow; 

                byte[] outStream = System.Text.Encoding.ASCII.GetBytes(txt_log.Text + "$"); // tablica bajtow dla strumienia wyjsciowego gdzie odczytywane sa dane z tablicy 
                serverStream.Write(outStream, 0, outStream.Length); // wysylanie wiadomosci na serwer
                serverStream.Flush(); //system IO, Wszelkie dane wcześniej zapisane w buforze są kopiowane do pliku, a bufor jest czyszczony z wyjątkiem stanu enkodera.

                ctThread = new Thread(getMessage); //watek do pobierania wiadomosci
                //Thread ctThread = new Thread(getMessage);
                ctThread.Start();
                //ograniczanie widocznosci 
                txt_chat.Visible = true;
                txt_msg.Visible = true;
                btn_send.Visible = true;
                btn_logout.Enabled = true;
                button1.Enabled = false;
                btn_login.Enabled = false;
                button2.Enabled = false;
                lst_kontakty.Visible = true;
                btn_lst.Visible = true;
                lst_prv.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                label5.Visible = true;
                label2.Visible = true;

            }
        }
        //---Puszczenie wiadomości--- obsluga przycisku wysylania wiadomosci po zalogowaniu
        private void btn_send_Click(object sender, EventArgs e)
        {
            byte[] outStream = System.Text.Encoding.ASCII.GetBytes(txt_msg.Text + "$");
            serverStream.Write(outStream, 0, outStream.Length);
            serverStream.Flush(); //system IO, Wszelkie dane wcześniej zapisane w buforze są kopiowane do pliku// a bufor jest czyszczony z wyjątkiem stanu enkodera.
        }
        //---Odebranie wiadmosci z serwera---
        private void getMessage()
        {
            while (true)
            {
                try
                {

                    serverStream = clientSocket.GetStream();  //odszukanie strumienia         
                    byte[] inStream = new byte[10025]; //**********************
                    buffSize = clientSocket.ReceiveBufferSize; //zwrocenie rozmairu bufora
                    serverStream.Read(inStream, 0, buffSize); //odczytanie bufora
                    string returndata = System.Text.Encoding.ASCII.GetString(inStream); //pobranie danych w strumieniu

                    readData = "" + returndata;                 
                    msg();
                    //var reader = new BinaryReader(clientSocket.GetStream());
                    //var response = reader.ReadString();
                    //lst_kontakty.Items.Add(reader);
                    
                                       
                }
                catch (Exception e)
                {
                    ctThread.Abort();
                    clientSocket.Close();
                    serverStream.Close();
                    //--- Brak wiadomości---
                }
            }
        }
        //---Wyświetlanie odebranej wiadomości---
        private void msg()
        {
            if (this.InvokeRequired) //zwraca wskazana wartosc do danego formatu, obiekt wywolujacy jest w innym watku niz format ktory zostal utworzony
                this.Invoke(new MethodInvoker(msg)); // odwolanie do metody invoker
            else
                txt_chat.Text = txt_chat.Text + Environment.NewLine + " >> " + readData; //zwraca text w nowej lini z odczytaniem go
            
        }
        //logowanie
        private void button1_Click(object sender, EventArgs e) // typowe logowanie
        {
            try
            {
                if (textBox1.Text.Length == 0 || txt_pass.Text.Length == 0)
                {
                    MessageBox.Show("Puste pola wymagają wypełnienia", "Błąd");
                }
                else
                {
                   // fullpath = @"C:\"; //Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                   // var sr = new System.IO.StreamReader(fullpath + textBox1.Text + "\\login.ID");
                    var sr = new System.IO.StreamReader("C:\\ProgramUsers\\" + textBox1.Text + "\\login.ID");
                    user = sr.ReadLine();
                    pass = sr.ReadLine();
                    login = sr.ReadLine();
                    sr.Close();
                    if (user == textBox1.Text && pass == txt_pass.Text)
                    {
                        btn_login.Enabled = true;
                        txt_log.Text = login;
                    }
                    else
                        MessageBox.Show("Błąd", "Błędny login lub hasło");
                    button1.Enabled = false;
                    button2.Enabled = false;

                }
            }
            catch (System.IO.DirectoryNotFoundException ex)
            {
                MessageBox.Show("Takie konto nie istnieje - sprawdź poprawność", "Błąd");
            }
        }

        private void button2_Click(object sender, EventArgs e) //przycisk przenoszacy do rejestracji
        {
            Rejestracja form2 = new Rejestracja();
            form2.Show();
        }

        //wylogowanie
        private void btn_logout_Click(object sender, EventArgs e) // wylogowanie z czata
        {
            txt_msg.Text = "";
            txt_chat.Text = "Klient rozlaczony";
            string koniec = "Klient rozlaczony";
            byte[] outStream = System.Text.Encoding.ASCII.GetBytes(koniec + "$");
            serverStream.Write(outStream, 0, outStream.Length);
            serverStream.Flush();
            ctThread.Abort();
            this.Hide();
            //serverStream.Close();
            //clientSocket.Close();
        }

        private void txt_chat_TextChanged(object sender, EventArgs e) //auto scroll 
        {
            txt_chat.SelectionStart = txt_chat.Text.Length;
            txt_chat.ScrollToCaret();
        }
        //pobieranie osób z serwera(nie wiem dlaczego zrobił mi się tu button 3 ale program to ogarnia
        private void button3_Click(object sender, EventArgs e)
        {
            lst_kontakty.Items.Clear();
            string path = @"C:\ProgramUsers\client.txt";
            //nie trzeba sprawdzac czy plik istnieje gdyz na pewno ma jednego klienta ktory chce pobrac dane
            using (StreamReader r = new StreamReader(path))
            {
                string line;
                while ((line = r.ReadLine()) != null)
                {
                    lst_kontakty.Items.Add(line);
                }
            }
            

        }
        //zegar
        private void timer1_Tick(object sender, EventArgs e)
        {

            label3.Text = DateTime.Now.ToString("HH:mm:ss");
        }
        //dodawanie znajomych
        private void button3_Click_1(object sender, EventArgs e)
        {
            using (StreamWriter sw = File.AppendText("C:\\ProgramUsers\\" + textBox1.Text + "\\friends.txt"))
            {
                sw.WriteLine(lst_kontakty.SelectedItem);
                lst_prv.Items.Add(lst_kontakty.SelectedItem);
                sw.Close();
            }
        }
        //usuwanie znajomych 
        private void button4_Click(object sender, EventArgs e)
        {
            lst_prv.Items.Remove(lst_prv.SelectedItem);//usuwa wybrany element z lst_prv
            System.IO.File.Delete("C:\\ProgramUsers\\" + textBox1.Text + "\\friends.txt");//usuwa cały plik
            //tworzy plik ze znajomymi na nowo
            FileStream fs = new FileStream("C:\\ProgramUsers\\" + textBox1.Text + "\\friends.txt", FileMode.OpenOrCreate, FileAccess.Write);
            System.IO.StreamWriter file1 = new System.IO.StreamWriter(fs);
            foreach (object o in lst_prv.Items)
            {
                 file1.WriteLine(o.ToString() );
            }
             file1.Flush();
             file1.Close();
             fs.Close();
            

        }

        
    }
}
