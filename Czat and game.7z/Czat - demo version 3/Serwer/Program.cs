﻿using System;
using System.Threading;
using System.Net.Sockets;
using System.Text;
using System.Collections;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
using System.Reflection;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        public static Hashtable clientsList = new Hashtable(); // tworzenie tablicy haszującej, struktury danych do porównywania dancyh i szybszego dostępu dla listy klienckiej

        static void Main(string[] args)
        {
            //---Utworzenie listnera---

            string path = @"C:\ProgramUsers\client.txt";
            int port = 8888; //port
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            TcpListener serverSocket = new TcpListener(ip, port);
            TcpClient clientSocket = default(TcpClient);
            int counter = 0; //licznik to wysylania na serwer

            // Przed rozpoczeciem pracy serwera zajmujemy sie plikiem z klientamijesli plik nie istnieje tworzymy go
            if (!File.Exists(path))
            {
                using (StreamWriter sw = File.CreateText(path))
                {
                }

            }
            else //jezeli jest to czyscimy dane z poprzedniej sesji
            {
                File.WriteAllText(path, string.Empty);
            }

            //---Odpalenie serwera---
            serverSocket.Start();
            Console.WriteLine("Serwer rozpoczął pracę ....");
            counter = 0;
            while ((true))
            {
                //---Akceptacja klienta---
                counter += 1;
                clientSocket = serverSocket.AcceptTcpClient();

                //NetworkStream ns = clientSocket.GetStream();
                //IPEndPoint remoteEP = (IPEndPoint)clientSocket.Client.RemoteEndPoint;
                //IPAddress clientip = remoteEP.Address;
                //string ipklienta = clientip.ToString() + Environment.NewLine;
                //byte[] array = Encoding.ASCII.GetBytes(ipklienta);
                //ns.Write(array, 0, array.Length);

                byte[] bytesFrom = new byte[10025];
                string dataFromClient = null;

                //---Stream danych---
                NetworkStream networkStream = clientSocket.GetStream();
                networkStream.Read(bytesFrom, 0, (int)clientSocket.ReceiveBufferSize);
                dataFromClient = System.Text.Encoding.ASCII.GetString(bytesFrom);
                dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"));

                //---Dodanie klienta do listy--- (WAZNE!!!)
                try
                {                   
                    clientsList.Add(dataFromClient, clientSocket); //dodawanie klienta do tabhash
                }
                catch
                {
                    int clnumber;
                    string clinetnumber;
                    Random r = new Random();
                    clnumber = r.Next(1000, 9999);
                    clinetnumber = clnumber.ToString();
                    clientsList.Add(dataFromClient + clinetnumber, clientSocket);
                    //clientsList.Remove(clientSocket);
                   // clientsList.Clear();
                }

                broadcast(dataFromClient + " Dolaczyl/a ", dataFromClient, false); //rozgloszenie o dolaczeniu klienta na serwer

                //DO PLIKU 
                //pobieranie ip podłączającego się klienta
                var pi = networkStream.GetType().GetProperty("Socket", BindingFlags.NonPublic | BindingFlags.Instance);
                string socketIp = ((Socket)pi.GetValue(networkStream, null)).RemoteEndPoint.ToString();
                
                //dodanie kolejnej line (metoda append) z nazwa klienta ip i portem
                using (StreamWriter sw = File.AppendText(path))
                {
                    sw.WriteLine(dataFromClient + " " + socketIp);
                    sw.Close();
                }
                            
                handleClinet client = new handleClinet();
                client.startClient(clientSocket, dataFromClient, clientsList);
               
               
                //Console.WriteLine(socketIp);
                //ns.Write(array, 0, array.Length);
            }

            //---Zamkniecie gniazda---
            clientSocket.Close();
            serverSocket.Stop();
            Console.WriteLine("Wyjście");
            Console.ReadLine();
        }

        //---Puszczenie wiadmomości do klientów---
        public static void broadcast(string msg, string uName, bool flag)
        {
            foreach (DictionaryEntry Item in clientsList)
            {
                TcpClient broadcastSocket;
                broadcastSocket = (TcpClient)Item.Value;
                NetworkStream broadcastStream = broadcastSocket.GetStream();
                Byte[] broadcastBytes = null;

                if (flag == true)
                {
                    broadcastBytes = Encoding.ASCII.GetBytes(uName + " mowi : " + msg);
                }
                else
                {
                    broadcastBytes = Encoding.ASCII.GetBytes(msg);
                }

                broadcastStream.Write(broadcastBytes, 0, broadcastBytes.Length);
                broadcastStream.Flush(); //system IO, Wszelkie dane wcześniej zapisane w buforze są kopiowane do pliku, a bufor jest czyszczony z wyjątkiem stanu enkodera.
            }
        }  //---Zakończenie funkcji---
    }//---Koniec klasy głownej---

    //---Klasa "załatwiajaca" klienta---
    public class handleClinet
    {
        TcpClient clientSocket;
        string clNo;
        Hashtable clientsList;

        public void startClient(TcpClient inClientSocket, string clineNo, Hashtable cList) // odpalenie klienta
        {

            this.clientSocket = inClientSocket;
            this.clNo = clineNo; //numerowanie klientow
            //---Lista klientow--- (Może sie przydać do listy kontaktów)
            this.clientsList = cList; 
            Thread ctThread = new Thread(doChat);
            ctThread.Start();
        }

        //---Wyświetlanie informacji na serwerze---
        private void doChat()
        {
            int requestCount = 0; //********************
            byte[] bytesFrom = new byte[10025]; //***************
            string dataFromClient = null; 
            //Byte[] sendBytes = null;
            //string serverResponse = null;
            string rCount = null; 
            requestCount = 0;

            while ((true))
            {
                try
                {
                    requestCount = requestCount + 1;
                    NetworkStream networkStream = clientSocket.GetStream();
                    networkStream.Read(bytesFrom, 0, (int)clientSocket.ReceiveBufferSize);
                    dataFromClient = System.Text.Encoding.ASCII.GetString(bytesFrom);
                    dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"));
                    Console.WriteLine("From client - " + clNo + " : " + dataFromClient);
                    rCount = Convert.ToString(requestCount);
                    Program.broadcast(dataFromClient, clNo, true);

                }
                catch 
                {
                    //clientSocket.Client.Close();
                    //dataFromClient = "koniec";
                    Console.WriteLine("Klient rozlaczony: " + clNo);
                    clientsList.Remove(clNo);
                    Console.ReadLine();
                    //Console.WriteLine(ex.ToString());
                }
            }
        }//---Zakończenie "doChat"
    }
    
}


